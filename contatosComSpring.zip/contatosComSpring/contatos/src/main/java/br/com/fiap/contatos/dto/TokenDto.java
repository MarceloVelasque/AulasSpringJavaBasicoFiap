package br.com.fiap.contatos.dto;

public record TokenDto(String token) {
}
